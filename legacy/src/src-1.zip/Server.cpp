#define CROW_MAIN
#define ASIO_STANDALONE 
#include "crow_all.h"
#include "SocialNetwork.h"
#include "NetworkStorage.h"
#include "User.h"
#include <iostream>

int main() {
    // =================================================================================
    // 1. INICIALIZAÇÃO DO MOTOR E BANCO DE DADOS
    // =================================================================================
    std::cout << ">> Inicializando o motor da Rede Social...\n";
    SocialNetwork sn;
    NetworkStorage storage("rede_social.db");
    
    try {
        storage.load(&sn);
        std::cout << ">> Banco de dados carregado com sucesso!\n";
    } catch (...) {
        std::cout << ">> Aviso: Iniciando banco novo ou erro na leitura.\n";
    }

    // =================================================================================
    // 2. CONFIGURAÇÃO DAS ROTAS (ENDPOINTS)
    // =================================================================================
    crow::SimpleApp app;

    // -------------------------------------------------------------------------
    // GRUPO: ROTAS DE LEITURA (GET) - Apenas consultam dados
    // -------------------------------------------------------------------------

    // ROTA RAIZ: Página de boas-vindas
    CROW_ROUTE(app, "/")
    ([](){
        return "<h1>Jam Guild API</h1><p>Backend C++ rodando! Use /api/signup para criar contas.</p>";
    });

    // ROTA STATUS: Verifica saúde do servidor
    CROW_ROUTE(app, "/api/status")
    ([&sn](){
        crow::json::wvalue x;
        x["status"] = "Online";
        x["server"] = "Jam Guild C++ Backend";
        x["profiles_count"] = sn.getProfilesAmount();
        return x;
    });

    // ROTA PERFIL: Busca dados de um usuário pelo ID
    CROW_ROUTE(app, "/api/profile/<int>")
    ([&sn](int id){
        try {
            Profile* p = sn.getProfile(id);
            crow::json::wvalue json;
            json["id"] = p->getId();
            json["name"] = p->getName();
            json["bio"] = p->getBio();
            json["type"] = p->getRole();
            
            User* u = dynamic_cast<User*>(p);
            if (u) json["verified"] = u->isVerified();

            return crow::response(json);
        } catch (...) {
            return crow::response(404, "{\"error\": \"User not found\"}");
        }
    });

    // ROTA TIMELINE: Busca os posts de um usuário
    CROW_ROUTE(app, "/api/timeline/<int>")
    ([&sn](int userId){
        try {
            Profile* p = sn.getProfile(userId);
            User* u = dynamic_cast<User*>(p);
            if (!u) return crow::response(400, "Apenas usuarios tem timeline");

            std::vector<Post*> timeline = sn.getTimeline(u);
            crow::json::wvalue x;
            
            int i = 0;
            for (auto* post : timeline) {
                x[i]["author"] = post->getOwner()->getName();
                x[i]["text"] = post->getText();
                x[i]["date"] = post->getFormattedDate();
                x[i]["type"] = post->getType();
                i++;
            }
            return crow::response(x);
        } catch (...) {
            return crow::response(404, "Usuario nao encontrado");
        }
    });

    // -------------------------------------------------------------------------
    // GRUPO: ROTAS DE ESCRITA (POST) - Modificam o banco de dados
    // -------------------------------------------------------------------------

    // ROTA CADASTRO: Cria um novo usuário
    // JSON esperado: { "username": "Nome", "type": "USER" }
    CROW_ROUTE(app, "/api/signup").methods(crow::HTTPMethod::Post)
    ([&sn, &storage](const crow::request& req){ 
        auto x = crow::json::load(req.body);
        if (!x) return crow::response(400, "JSON invalido");

        std::string username = x["username"].s();
        std::string password = x["password"].s();

        if (username.empty() || password.empty()) 
            return crow::response(400, "Username e Password sao obrigatorios");

        try {
            // Removemos o parâmetro "type", pois sempre será USER aqui
            Profile* newP = sn.signUp(username, password);
            
            storage.saveUser(newP); 

            crow::json::wvalue resp;
            resp["message"] = "Usuario criado com sucesso!";
            resp["id"] = newP->getId();
            return crow::response(201, resp);
        } catch (const std::exception& e) {
            return crow::response(500, e.what());
        }
    });

    // =================================================================================
    // >>> ESPAÇO RESERVADO PARA FUTURAS ROTAS <<<
    // Coloque aqui:
    // - POST /api/post (Criar postagem)
    // - POST /api/connect (Seguir alguém)
    // =================================================================================

    // ... NOVAS ROTAS AQUI ...


    // =================================================================================
    // 3. START DO SERVIDOR
    // =================================================================================
    std::cout << ">> Servidor rodando em http://127.0.0.1:8085\n";
    // Bind em 0.0.0.0 para evitar conflitos de IP no Windows
    app.bindaddr("0.0.0.0").port(8085).multithreaded().run();
    
    return 0;
}