#include "ProfileNotFound.h"

using namespace std;

ProfileNotFound:: ProfileNotFound () : logic_error("Profile Not Found") {};